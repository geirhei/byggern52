/*
 * sram.h
 *
 * Created: 06.11.2015 09:50:46
 *  Author: geirhei
 *
 *
 *	Used for testing of the SRAM component
 */ 


#ifndef SRAM_H_
#define SRAM_H_

#include <avr/io.h>

void SRAM_test(void);
void SRAM_test2(void);



#endif /* SRAM_H_ */